## Florette Broccolini

This interactive storybook was a final project for my Spring 2016 Data Visualization course.  We conceived it as a tool to help teach kids the importance of good nutrition and eating habits.  It was pretty fun getting to know basic HTML, CSS, and JavaScript as well as get my feet wet with D3.

Shoutout to Steve for artistic magic and Brian for D3 wizardry.

NOTES FOR USE:

Please start with the "title" html file and ensure you use a browser with local file access enabled (https://github.com/mrdoob/three.js/wiki/How-to-run-things-locally).
If it seems to be acting up, drag the file onto your browser shortcut to open it instead of a double-click - this tends to help.

*Data shortcuts were taken due to time constraints.
**Also, this was created before I knew what Bootstrap or jQuery was.